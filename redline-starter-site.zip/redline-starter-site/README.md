# Redline Starter Website

A responsive multi-page HTML/CSS/JavaScript website designed for GitHub Pages and phone-based editing.

## Files
- `index.html` — home page
- `about.html` — about page
- `projects.html` — project cards
- `contact.html` — social/contact links
- `assets/style.css` — shared design and responsive layout
- `assets/script.js` — mobile menu and automatic footer year

## Publish with GitHub Pages
1. Create a GitHub repository named `redline-website` (public if using GitHub Free).
2. Upload all files and folders, keeping the structure above.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main`, folder `/(root)`, then press **Save**.
6. Wait for the deployment to finish, then open the website URL shown on the Pages settings screen.

## Editing
Edit the HTML files to change content, `assets/style.css` to change styling, and `assets/script.js` to change interactions. Commit/push changes to `main` and Pages will redeploy.

## Important
This is a static site. Do not put passwords, private tokens, or sensitive personal information in the repository. A public contact form needs a separate service or backend.
